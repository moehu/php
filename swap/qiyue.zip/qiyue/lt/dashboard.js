
// JS��ΪDashboard �Ų���
    // @ccdalao
    // =================================================================
    // С��������
    // -----------------------------------------------------------------
    // http://www.xiaomol.cn
    // =================================================================


$(window).on('load', function() {



     // @ccdalao
    // =================================================================
    // С��������
    // -----------------------------------------------------------------
    // http://www.xiaomol.cn
    // =================================================================

    var day_data = [
        {"elapsed": "ֵ-12", "value": 24, b:2},
        {"elapsed": "ֵ-13", "value": 34, b:22},
        {"elapsed": "ֵ-14", "value": 33, b:7},
        {"elapsed": "ֵ-15", "value": 22, b:6},
        {"elapsed": "ֵ-16", "value": 28, b:17},
        {"elapsed": "ֵ-17", "value": 60, b:15},
        {"elapsed": "ֵ-18", "value": 60, b:17},
        {"elapsed": "ֵ-19", "value": 70, b:7},
        {"elapsed": "ֵ-20", "value": 67, b:18},
        {"elapsed": "ֵ-21", "value": 86, b: 18},
        {"elapsed": "ֵ-22", "value": 86, b: 18},
        {"elapsed": "ֵ-23", "value": 113, b: 29},
        {"elapsed": "ֵ-24", "value": 130, b: 23},
        {"elapsed": "ֵ-25", "value": 114, b:10},
        {"elapsed": "ֵ-26", "value": 80, b:22},
        {"elapsed": "ֵ-27", "value": 109, b:7},
        {"elapsed": "ֵ-28", "value": 100, b:6},
        {"elapsed": "ֵ-29", "value": 105, b:17},
        {"elapsed": "ֵ-30", "value": 110, b:15},
        {"elapsed": "ֵ-31", "value": 102, b:17},
        {"elapsed": "ֵ-01", "value": 107, b:7},
        {"elapsed": "ֵ-02", "value": 60, b:18},
        {"elapsed": "ֵ-03", "value": 67, b: 18},
        {"elapsed": "ֵ-04", "value": 76, b: 18},
        {"elapsed": "ֵ-05", "value": 73, b: 29},
        {"elapsed": "ֵ-06", "value": 94, b: 13},
        {"elapsed": "ֵ-07", "value": 135, b:2},
        {"elapsed": "ֵ-08", "value": 154, b:22},
        {"elapsed": "ֵ-09", "value": 120, b:7},
        {"elapsed": "ֵ-10", "value": 100, b:6},
        {"elapsed": "ֵ-11", "value": 130, b:17},
        {"elapsed": "ֵ-12", "value": 100, b:15},
        {"elapsed": "ֵ-13", "value": 60, b:17},
        {"elapsed": "ֵ-14", "value": 70, b:7},
        {"elapsed": "ֵ-15", "value": 67, b:18},
        {"elapsed": "ֵ-16", "value": 86, b: 18},
        {"elapsed": "ֵ-17", "value": 86, b: 18},
        {"elapsed": "ֵ-18", "value": 113, b: 29},
        {"elapsed": "ֵ-19", "value": 130, b: 23},
        {"elapsed": "ֵ-20", "value": 114, b:10},
        {"elapsed": "ֵ-21", "value": 80, b:22},
        {"elapsed": "ֵ-22", "value": 109, b:7},
        {"elapsed": "ֵ-23", "value": 100, b:6},
        {"elapsed": "ֵ-24", "value": 105, b:17},
        {"elapsed": "ֵ-25", "value": 110, b:15},
        {"elapsed": "ֵ-26", "value": 102, b:17},
        {"elapsed": "ֵ-27", "value": 107, b:7},
        {"elapsed": "ֵ-28", "value": 60, b:18},
        {"elapsed": "ֵ-29", "value": 67, b: 18},
        {"elapsed": "ֵ-30", "value": 76, b: 18},
        {"elapsed": "ֵ-01", "value": 73, b: 29},
        {"elapsed": "ֵ-02", "value": 94, b: 13},
        {"elapsed": "ֵ-03", "value": 79, b: 24}
    ];

     var chart = Morris.Area({
        element : 'morris-chart-network',
        data: day_data,
        axes:false,
        xkey: 'elapsed',
        ykeys: ['value', 'b'],
        labels: ['cpuռ��', '�Ա�'],
        yLabelFormat :function (y) { return y.toString() + ''; },
        gridEnabled: false,
        gridLineColor: 'transparent',
        lineColors: ['#82c4f8','#0d92fc'],
        lineWidth:[0,0],
        pointSize:[0,0],
        fillOpacity: 1,
        gridTextColor:'#999',
        parseTime: false,
        resize:true,
        behaveLikeLine : true,
        hideHover: 'auto'
    });








    // @ccdalao
    // =================================================================
    // С��������
    // -----------------------------------------------------------------
    // http://www.xiaomol.cn
    // =================================================================
    var hddSparkline = function() {
        $("#demo-sparkline-area").sparkline([57,69,70,62,73,79,76,77,73,52,57,50,60,55,70,68], {
            type: 'line',
            width: '100%',
            height: '40',
            spotRadius: 5,
            lineWidth: 1.5,
            lineColor:'rgba(255,255,255,.85)',
            fillColor: 'rgba(0,0,0,0.03)',
            spotColor: 'rgba(255,255,255,.5)',
            minSpotColor: 'rgba(255,255,255,.5)',
            maxSpotColor: 'rgba(255,255,255,.5)',
            highlightLineColor : '#ffffff',
            highlightSpotColor: '#ffffff',
            tooltipChartTitle: 'ֵ',
            tooltipSuffix:' %'

        });
    }



    // @ccdalao
    // =================================================================
    // С��������
    // -----------------------------------------------------------------
    // http://www.xiaomol.cn
    // =================================================================

    var earningSparkline = function(){
        $("#demo-sparkline-line").sparkline([0,0,0,0,0,0,0,0,25,3,5], {
            type: 'line',
            width: '100%',
            height: '40',
            spotRadius: 4,
            lineWidth:1,
            lineColor:'#ffffff',
            fillColor: false,
            minSpotColor :false,
            maxSpotColor : false,
            highlightLineColor : '#ffffff',
            highlightSpotColor: '#ffffff',
            tooltipChartTitle: 'ֵ',
            tooltipPrefix :'�� ',
            spotColor:'#ffffff',
            valueSpots : {
                '0:': '#ffffff'
            }
        });
    }


    // @ccdalao
    // =================================================================
    // С��������
    // -----------------------------------------------------------------
    // http://www.xiaomol.cn
    // =================================================================

    var barEl = $("#demo-sparkline-bar");
    var barValues = [0,0,0,2,1,0,1,0,0,1,2,1,2,3,0,0,0,0,0,0,1,0,0,1,0,0,0,1,0,1,1,0,1,0,0,0,0];
    var barValueCount = barValues.length;
    var barSpacing = 1;
    var salesSparkline = function(){
         barEl.sparkline(barValues, {
            type: 'bar',
            height: 55,
            barWidth: Math.round((barEl.parent().width() - ( barValueCount - 1 ) * barSpacing ) / barValueCount),
            barSpacing: barSpacing,
            zeroAxis: false,
            tooltipChartTitle: '��',
            tooltipSuffix: '����',
            barColor: 'rgba(255,255,255,.7)'
        });
    }


    $(window).on('resizeEnd', function(){
        hddSparkline();
        earningSparkline();
        salesSparkline();
    })
    hddSparkline();
    earningSparkline();
    salesSparkline();


    // @ccdalao
    // =================================================================
    // С��������
    // -----------------------------------------------------------------
    // http://www.xiaomol.cn
    // =================================================================
    $('#demo-panel-network-refresh').niftyOverlay().on('click', function(){
        var $el = $(this), relTime;

        $el.niftyOverlay('show');


        relTime = setInterval(function(){
            $el.niftyOverlay('hide');
            clearInterval(relTime);
        },2000);
    });








    // CcDlao������ôһ������������ӭ���ǵ��û�����
    // =============================================================================================
    // ͬ����Ҳ��Ϊ�˷�ֹĳЩ����HTML��ֻ��ĺ���Ӣ�ﶼ�ϲ��õ�Сѧ�������ҵ�ģ�壬��Ϊ�����˲���js��[����]
    // =============================================================================================
    $.niftyNoty({
        type: 'dark',
        title: '��ӭ����С��������.',
        message: '���������ǵ��û����ģ�ͬ��Ҳ�ǿ���̨.',
        container: 'floating',
        timer: 10000
    });

});