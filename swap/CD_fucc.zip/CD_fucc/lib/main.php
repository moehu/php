<?php
if (!function_exists('plug_eva_temp')) {
   function plug_eva_temp($name,$nr){
		$return=plug_eva('template_Hostme',$name);
		if($return==""){plug_eva('template_Hostme',$name,$nr);$return=plug_eva('template_Hostme',$name);}
		return $return;
	}
}




$tsz['电脑模板地址']=str_replace('/templates/CD_WIN10',TEMPLATE::assign('templatedir'),plug_eva_temp("电脑模板壁纸",'/templates/CD_WIN10/win10-ui/img/wallpapers/pc.png'));	

$tsz['手机模板地址']=str_replace('/templates/CD_WIN10',TEMPLATE::assign('templatedir'),plug_eva_temp("手机模板壁纸",'/templates/CD_WIN10/win10-ui/img/wallpapers/wap.jpeg'));

$tsz['网易云外链地址']=str_replace('/templates/CD_WIN10',TEMPLATE::assign('templatedir'),plug_eva_temp("网易云外链地址",'http://music.163.com/outchain/player?type=2&id=41500546&auto=0&height=66'));

$tsz['友链地址①']=str_replace('/templates/CD_WIN10',TEMPLATE::assign('templatedir'),plug_eva_temp("友链地址①",'http://www.xiaomol.cn'));
$tsz['友链①名字']=str_replace('/templates/CD_WIN10',TEMPLATE::assign('templatedir'),plug_eva_temp("友链①名字",'小茉莉主机'));

$tsz['友链地址②']=str_replace('/templates/CD_WIN10',TEMPLATE::assign('templatedir'),plug_eva_temp("友链地址②",'http://www.baidu.com'));
$tsz['友链②名字']=str_replace('/templates/CD_WIN10',TEMPLATE::assign('templatedir'),plug_eva_temp("友链②名字",'百度'));

$tsz['友链地址③']=str_replace('/templates/CD_WIN10',TEMPLATE::assign('templatedir'),plug_eva_temp("友链地址③",'http://www.baidu.com'));
$tsz['友链③名字']=str_replace('/templates/CD_WIN10',TEMPLATE::assign('templatedir'),plug_eva_temp("友链③名字",'小茉莉主机'));



				
TEMPLATE::assign('tempsz',$tsz);
$uid=session('uid');
SMACSQL()->select('服务单表', 'count(*)', "(状态='开放' OR 状态='客服回答') AND uid='{$uid}'");
$OpenTickets = SMACSQL()->fetch_assoc();
$OpenTicket=$OpenTickets['count(*)'];
TEMPLATE::assign('OpenTicket',$OpenTicket);
SMACSQL()->select('服务单表', 'count(*)',"uid='{$uid}'");
$SumTickets = SMACSQL()->fetch_assoc();
$SumTicket=$SumTickets['count(*)'];
$PerTicket=$OpenTicket/$SumTicket*100;
TEMPLATE::assign('PerTicket',$PerTicket);
SMACSQL()->select('服务', 'count(*)', "(状态='激活' OR 状态='暂停') AND 帐号id='{$uid}'");
$ActiveServices = SMACSQL()->fetch_assoc();
$ActiveService=$ActiveServices['count(*)'];
TEMPLATE::assign('ActiveService',$ActiveService);
SMACSQL()->select('服务', 'count(*)', "帐号id='{$uid}'");
$SumServices = SMACSQL()->fetch_assoc();
$SumService=$SumServices['count(*)'];
TEMPLATE::assign('SumService',$SumService);
$PerService=$ActiveService/$SumService*100;
TEMPLATE::assign('PerService',$PerService);
SMACSQL()->select('服务', 'count(DATEDIFF(到期时间,开通时间))', "帐号id='{$uid}' AND DATEDIFF(到期时间,开通时间)<15");
$Dates = SMACSQL()->fetch_assoc();
$Date=$Dates['count(DATEDIFF(到期时间,开通时间))'];
TEMPLATE::assign('Date',$Date);
$s=TEMPLATE::assign('s');
$email = $s['登陆邮箱'];
$grav_sm = "http://gravatar.duoshuo.com/avatar/" . md5( strtolower( trim( $email ) ) ) . "?d=" . urlencode( $default ) . "&s=" . 25;
$grav_md = "http://gravatar.duoshuo.com/avatar/" . md5( strtolower( trim( $email ) ) ) . "?d=" . urlencode( $default ) . "&s=" . 40;
$grav_50 = "http://gravatar.duoshuo.com/avatar/" . md5( strtolower( trim( $email ) ) ) . "?d=" . urlencode( $default ) . "&s=" . 50;
$grav_lg = "http://gravatar.duoshuo.com/avatar/" . md5( strtolower( trim( $email ) ) ) . "?d=" . urlencode( $default ) . "&s=" . 138;
TEMPLATE::assign('grav_sm',$grav_sm);
TEMPLATE::assign('grav_md',$grav_md);
TEMPLATE::assign('grav_lg',$grav_lg);
TEMPLATE::assign('grav_50',$grav_50);

