<?php
D()->query("select * from 公告 order by 公告ID desc limit 0,4");
$news1 = array();$new1 = array();
while ($new1 = D()->fetch_assoc()) $news1[] = $new1;
D()->query("select * from 公告 order by 公告ID desc limit 4,4");
$news2 = array();$new2 = array();
while ($new2 = D()->fetch_assoc()) $news2[] = $new2;
$hu['news1']=$news1;
$hu['news2']=$news2;

TEMPLATE::assign('hu', $hu);