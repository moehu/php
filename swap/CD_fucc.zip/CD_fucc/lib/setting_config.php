<?php
$cjafile=SWAP_PLUGINS.'mbsysjk'.SWAP_DIR_END.'mbsysjk.php';
$template_config=array(
	array(
			'name'=>'注意',
			'type'=>'txt',
			'description'=>'
			当前为模板 <code>CD_WIN10</code>的配置界面！<br> 
			<br>
			因此如果设置无效等请联系模板作者 <code>CcDalao</code>的QQ<code>842105949</code>本人感激不尽，以身相许（是不可能的） '
		),

	
	
				array(
			'name'=>'电脑模板壁纸',
			'type'=>'text',
			'description'=>'直接输入图片链接'
		),
		array(
			'name'=>'手机模板壁纸',
			'type'=>'text',
			'description'=>'直接输入图片链接'
		),
		array(
			'name'=>'网易云外链地址',
			'type'=>'text',
			'description'=>'输入网易云外链链接 详情请看swap云中心模板资料'
		),
		
		
		array(
			'name'=>'友链①名字',
			'type'=>'text',
			'description'=>'输入友链名字'
		),
			array(
			'name'=>'友链地址①',
			'type'=>'text',
			'description'=>'输入链接'
		),
			array(
			'name'=>'友链②名字',
			'type'=>'text',
			'description'=>'同上'
		),
			array(
			'name'=>'友链地址②',
			'type'=>'text',
			'description'=>'输入链接'
		),
			array(
			'name'=>'友链③名字',
			'type'=>'text',
			'description'=>'同上'
		),
			array(
			'name'=>'友链地址③',
			'type'=>'text',
			'description'=>'同上！'
		),
		
	);

if(file_exists($cjafile)==true){
$template_config[]=array('name'=>'管理权限用户','type'=>'text','description'=>'哪些用户拥有进入管理权限 用逗号分开 例如root,admin');
$template_config[]=array('name'=>'管理独立密码','type'=>'text','description'=>'管理直接登陆的独立的密码');
}